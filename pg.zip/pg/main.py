import sys
import time
import pygame
import random
from collections import OrderedDict
from PIL import Image

FPS = 60
size = 3
margin = 10
qz_size = 100
size = min(max(size, 3), 5)
photo_height = 250
photo_width = 250
screen_height = qz_size * size + 280
screen_width = qz_size * size + margin + photo_width + 240

gsta = 0
stime = None
elaps_time = 0
over_time = size * size * 20

color_active = pygame.Color('dodgerblue2')
color_inactive = pygame.Color('lightskyblue3')
color = color_inactive

img_dict = [
    "20241120154510", "20241120155117", "20241120155439",
    "20241120155624", "20241120155735", "20241120155848",
    "20241120155955", "20241120160049", "20241120160153"
]
rand_nob = random.randint(0, 8)
rand_photo = img_dict[rand_nob]
imagee = Image.open('photo/{}.jpg'.format(rand_photo))
imagee = imagee.resize((photo_width, photo_height))
imagee.save("photo/{}.jpg".format(rand_photo))

txts = {
    "20241120154510": "犹太教堂和社区中心：已经在圣地亚哥市中心南部赛拉诺街（Serrano Street）的大犹太教堂"
                      "（Great Synagogue）经营了近五十年的犹太人社区，决定搬到城市东部，以超越单纯的宗教仪式，"
                      "容纳更大的社区、社交和文化活动。该建筑不仅要将不同类型、规模、类别和用途的项目组"
                      "合成一个有机整体，还需要营造大量象征以实现可自由漫步同时又富有整体感的空间体验。",
    "20241120155117": "SoHo 犹太教堂：犹太教堂是该社区有史以来第一座犹太教堂，希望呈现一种新的景象，"
                      "将犹太教的启迪传播给下一代。拉比Dovi Scheiner 和他的妻子 Esty 是 SoHo "
                      "犹太教堂的创始人，以前瞻性的思维方式创建了一个宗教平台，邀请社区成员将他们的宗教信仰与"
                      "现代生活方式深度融合起来。考虑到曼哈顿下城犹太人的开放心态，SoHo 犹太教堂尝试将犹太教堂"
                      "重塑为舒适愉快的场所，以实现个人成长和公共连接。",
    "20241120155439": "德累斯顿新犹太教堂：德累斯顿因两次毁坏而闻名：1938年11月9日“水晶之夜”（Reichskristallnacht）"
                      "中由戈特弗里德·森佩尔（Gottfried Semper）设计的犹太教堂被毁坏，以及1945年2月13日、"
                      "14日整座历史城市被盟军轰炸。这两次破坏具有历史上的内在关联，但在建筑上的后续发展"
                      "却截然不同。对于后者，德累斯顿重建了历史古迹，形成了不真实的连续性，对建筑的牢固性进行了"
                      "有问题的虚饰。而对于前者，新犹太教堂则呈现出对稳定与脆弱之间矛盾的尝试性探讨。",
    "20241120155624": "西奈神殿：西奈神殿是东湾（East Bay）最老、最大的犹太人教堂，新的建筑围绕着他们1918年"
                      "的地标圣堂发展起来，并且将所有不同的活动区分开来。西奈神殿的新加建筑包括一个新的小教堂，"
                      "一座幼儿园，一处图书馆，以及许多教室和行政办公室。最重要的是，西奈神殿希望用新的设计将"
                      "这些不同元素有机组合成一个场所，让他们的信众可以体会到更强烈的社区的感觉，人们可以在"
                      "休闲空间里见到彼此，并且自发地对话、交流。",
    "20241120155735": "娘子谷犹太教堂：娘子谷（Babyn Yar）是乌克兰基辅西部一个丛林茂盛的峡谷，"
                      "曾用于标记城市边缘。1941年9月29日-30日，大约35000名犹太人在这里被德国军队枪杀，"
                      "这是纳粹政权发动过的最惨烈的大屠杀之一。娘子谷大屠杀纪念基金会（Babyn Yar Holocaust "
                      "Memorial Foundation）在接下来的时间将置入一系列或大或小的设施来纪念这个地方"
                      "所经历过的一切。该计划目前已经启动，娘子谷犹太教堂是这项行动所呈现出的第一座建筑。",
    "20241120155848": "墨西哥犹太文献研究中心：这座犹太教堂与传统意义上的犹太教堂有所不同，它建成的必要性"
                      "来自于整个墨西哥犹太人团体希望能在一个安全且公共的场所保存、保护他们的历史。"
                      "这座新建筑位于墨西哥城重获生机的“罗马区”（Colonia Roma）1930年建成的 Rodfe Sedek"
                      "犹太教堂旁边，占地不大，兼作进入老犹太教堂的通道，是一座主要展示犹太人文化相关信息的"
                      "博物馆和文献图书馆，尤其是在墨西哥的犹太人文化。",
    "20241120155955": "柏林犹太人博物馆：在老的柏林犹太人博物馆建成54年之后，1987年，柏林政府"
                      "为它的扩建工程举行了一个匿名竞赛。竞赛举办方希望将犹太人二战后的生存方式重置于人们眼前。"
                      "众多赫赫有名的建筑师中，丹尼尔·里伯斯金最终胜出。只有他的建筑中贯穿了一种非凡、"
                      "庄重的设计，一种再现犹太人在大屠杀前后的生活剧变、概念性的表达设计。",
    "20241120160049": "哭墙：哭墙又称西墙、叹息之壁，是耶路撒冷旧城古代犹太国第二圣殿护墙的一段，"
                      "也是第二圣殿护墙的仅存遗址，长约50米，高约18米，由大石块筑成。犹太教（Judaism）"
                      "把该墙看作是第一圣地，教徒至该墙必须哀哭，以表示对圣殿的哀悼并期待其恢复。千百年来，"
                      "流落在世界各个角落的犹太人回到圣城耶路撒冷时，便会来到这面石墙前低声祷告，"
                      "哭诉流亡之苦，所以被称为“哭墙”。",
    "20241120160153": "摩西：摩西是以色列人的民族领袖，史学界认为他是犹太教创始者。在犹太教、基督教、伊斯兰教"
                      "里都被认为是极为重要的人物，按照以色列人的传承，摩西五经便是由其所著。摩西受上帝之命"
                      "率领被奴役的以色列人逃离古埃及，前往一块富饶之地迦南，经历40多年的艰难跋涉，"
                      "到达目的地的时候就在当地去世享年120岁。在摩西的带领下古以色列人摆脱了被奴役的悲惨命运，"
                      "学会遵守十诫，并成为历史上首个尊奉一神宗教的民族。"
}

background = "white"
BACKGROUND_QIZI_COLOR = "#9e948a"

imagee = Image.open('photo/{}.jpg'.format(rand_photo))
img_width = imagee.width
img_height = imagee.height
img_we = img_width / size
img_he = img_height / size

images_l = []
count = 1
for i in range(size):
    for j in range(size):
        leftup_y = i * img_he
        leftup_x = j * img_we
        rightdown_y = (i + 1) * img_he
        rightdown_x = (j + 1) * img_we
        tmp_s = (leftup_x, leftup_y, rightdown_x, rightdown_y)
        tmp_img = imagee.crop(tmp_s)
        tmp_img = tmp_img.resize((qz_size, qz_size))
        images_l.append(tmp_img)
        tmp_img.save('photo/imagee{}.jpg'.format(count))
        count += 1


def addtu(tuple1, tuple2):
    tmp = (tuple1[0] + tuple2[0], tuple1[1] + tuple2[1])
    return tmp


def print_text(screen, font, x, y, text, fcolor=(255, 255, 255)):
    imgText = font.render(text, True, fcolor)
    screen.blit(imgText, (x, y))


class Area:
    def __init__(self, size_=4):
        self.posi = [[1, 0], [-1, 0], [0, 1], [0, -1]]
        self.size = size_
        self.click_react = {'x': {}, 'y': {}}
        self.pos = OrderedDict()

        num = 1
        posxys = []
        for i in range(size_):
            for j in range(size_):
                posxys = tuple([i, j])
                self.pos[posxys] = num
                num += 1

        for i in range(100000):
            positions = random.choice(self.posi)
            change_op = addtu(posxys, positions)  # 相加移动
            if change_op in self.pos:
                tmp = self.pos[change_op]
                self.pos[change_op] = size_ * size_
                self.pos[posxys] = tmp
                posxys = change_op

        for y in range(self.size):
            for x in range(self.size):
                x0 = x * qz_size + margin
                x1 = (x + 1) * qz_size + margin
                click_x = (x0, x1)
                self.click_react['x'][click_x] = x

                y0 = y * qz_size + 150
                y1 = (y + 1) * qz_size + 150
                click_y = (y0, y1)
                self.click_react['y'][click_y] = y

    def move(self, x, y):
        xn = -1
        for i_, j_ in self.click_react['x'].items():
            if i_[0] <= x < i_[1]:
                xn = j_
                break
        if xn == -1:
            return False

        yn = -1
        for i_, j_ in self.click_react['y'].items():
            if i_[0] <= y < i_[1]:
                yn = j_
                break
        if yn == -1:
            return False

        for i_ in self.posi:
            ch_op = addtu((yn, xn), i_)

            if ch_op in self.pos:
                if self.pos[ch_op] == self.size * self.size:
                    self.pos[ch_op], self.pos[(yn, xn)] = self.pos[(yn, xn)], \
                        self.pos[ch_op]
                    break

    def win_(self):
        number = 1
        for i in range(self.size):
            for j in range(self.size):
                if self.pos[(i, j)] == number:
                    number += 1
                    continue
                else:
                    return False
        return True


def game_init():
    pygame.init()
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("游戏")
    return screen


def draw_img(qipan, screen):
    for i in range(qipan.size):
        for j in range(qipan.size):
            temp = qipan.pos[(i, j)]
            if temp == qipan.size * qipan.size:
                color = pygame.Color(BACKGROUND_QIZI_COLOR)
                x = qz_size * j + 40
                y = qz_size * i + 140
                pygame.draw.rect(screen, color, (x, y, qz_size, qz_size))
            else:
                img = pygame.image.load("photo/imagee{}.jpg".format(temp)).convert()
                screen.blit(img, (j * qz_size + 40, i * qz_size + 140))
    global rand_photo

    img = pygame.image.load('photo/{}.jpg'.format(rand_photo)).convert()
    screen.blit(img, (size * qz_size + 2 * margin + 175, margin + 50))


def press(game_over, qipan, NOb, times):
    global gsta, stime, elaps_time
    for event in pygame.event.get():
        if event.type == NOb and not game_over:
            times += 1
        elif event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONUP:
            if gsta == 0:
                gsta = 1
                stime = time.time()
                elaps_time = 0
            if event.button == 1 and not game_over:
                x, y = event.pos
                if (size * qz_size + 2 * margin + 150 <= x <= size * qz_size + 2 * margin +
                        150 + photo_width and margin + 50 <= y <= margin + 50 + photo_height):
                    return -413
                xnum = -1
                for i_, j_ in qipan.click_react['x'].items():
                    if i_[0] <= x < i_[1]:
                        xnum = j_
                        break
                if xnum == -1:
                    return False

                ynum = -1
                for i_, j_ in qipan.click_react['y'].items():
                    if i_[0] <= y < i_[1]:
                        ynum = j_
                        break
                if ynum == -1:
                    return False
                for i_ in qipan.posi:
                    change_op = addtu((ynum, xnum), i_)

                    if change_op in qipan.pos:
                        if qipan.pos[change_op] == qipan.size * qipan.size:
                            qipan.pos[change_op], qipan.pos[(ynum, xnum)] = qipan.pos[
                                (ynum, xnum)], qipan.pos[change_op]
                            break
        elif event.type == pygame.KEYDOWN and event.key == 13:
            return True
    if NOb:
        return times


def game_over_win(screen, qipan, clock, size_, text="Win"):
    font = pygame.font.SysFont('Blod', int(100))
    font_width, font_height = font.size(str(text))
    while True:
        if press(True, qipan, None, None):
            break
        screen.fill(pygame.Color(background))
        draw_img(qipan, screen)
        font1 = pygame.font.Font('photo/arial.ttf', 20)
        tmp_time = size_ * size_ * 20 - 60 - elaps_time
        print_text(screen, font1, 50, 55, '%03d' % tmp_time, (200, 40, 40))
        screen.blit(font.render(str(text), True, (0, 0, 0)),
                    ((screen_width - font_width) / 2, (screen_height - font_height) / 2 + 200))
        print_text(screen, font, 2 * margin + 120, margin + 40,
                   "点击图片更换拼图图片", (0, 0, 0))
        print_text(screen, font, 2 * margin + 120, margin + 60,
                   "完成拼图之后可以点击回车重新开始", (0, 0, 0))
        pygame.display.update()
        clock.tick(FPS)


def game_over_lose(screen, q, clock, text="Lose"):
    font = pygame.font.SysFont('Blod', int(100))
    font_width, font_height = font.size(str(text))
    while True:
        if press(True, q, None, None):
            break
        screen.fill(pygame.Color(background))
        draw_img(q, screen)
        font1 = pygame.font.Font('photo/arial.ttf', 20 * 2)
        print_text(screen, font1, 50, 55, '%03d' % 0, (200, 40, 40))
        screen.blit(font.render(str(text), True, (0, 0, 0)),
                    ((screen_width - font_width) / 2, (screen_height - font_height) / 2 + 200))
        print_text(screen, font, 2 * margin + 120, margin + 40,
                   "点击图片更换拼图图片", (0, 0, 0))
        print_text(screen, font, 2 * margin + 120, margin + 60,
                   "完成拼图之后可以点击回车重新开始", (0, 0, 0))
        pygame.display.update()
        clock.tick(FPS)


def main():
    screen = game_init()
    font1 = pygame.font.Font('photo/arial.ttf', 20 * 2)
    temp_size = 4
    assert temp_size < 5
    global gsta, stime, elaps_time
    gsta = 0
    stime = None
    elaps_time = 0
    otime = 320
    clock = pygame.time.Clock()
    q = Area(temp_size)
    NOb = pygame.USEREVENT + 1
    pygame.time.set_timer(NOb, 1000)
    times = 0
    rand_nob1 = random.randint(0, 8)
    global rand_nob
    global rand_photo
    rand_nob = rand_nob1
    rand_photo = img_dict[rand_nob]
    img = Image.open('photo/{}.jpg'.format(rand_photo))
    img = img.resize((photo_width, photo_height))
    img.save("photo/{}.jpg".format(rand_photo))
    img = Image.open('photo/{}.jpg'.format(rand_photo))
    imgwidth = img.width
    imgheight = img.height
    imgwe = imgwidth / temp_size
    imghe = imgheight / temp_size
    img_list = []
    cnt = 1
    for i in range(temp_size):
        for j in range(temp_size):
            leftupy = i * imghe
            leftupx = j * imgwe
            rightdowny = (i + 1) * imghe
            rightdownx = (j + 1) * imgwe
            tmps = (leftupx, leftupy, rightdownx, rightdowny)
            tmpimg = img.crop(tmps)
            tmpimg = tmpimg.resize((qz_size, qz_size))
            img_list.append(tmpimg)
            tmpimg.save('photo/imagee{}.jpg'.format(cnt))
            cnt += 1

    while True:
        if q.win_():
            break
        if elaps_time == otime:
            break
        if gsta == 1:
            elaps_time = int(time.time() - stime)

        times = press(False, q, NOb, times)
        if times == -413:
            break
        screen.fill(pygame.Color(background))
        print_text(screen, font1, 50, 55, '%03d' % (otime - elaps_time),
                   (200, 40, 40))
        draw_img(q, screen)
        font = pygame.font.SysFont('KaiTi', 12)
        print_text(screen, font, 2 * margin + 120, margin + 40,
                   "点击图片更换拼图图片", (0, 0, 0))
        print_text(screen, font, 2 * margin + 120, margin + 60,
                   "完成拼图或超时失败之后", (0, 0, 0))
        print_text(screen, font, 2 * margin + 120, margin + 80,
                   "可以点击回车重新开始", (0, 0, 0))
        texts = []
        text = txts[rand_photo]
        s = 0
        e = 0
        now = 0
        for z in range(len(text)):
            if text[z].isascii():
                now += 0.5
            else:
                now += 1
            e += 1
            if now >= 20:
                texts.append(text[s:e])
                s = e
                now = 0
        if len(texts) == 0:
            texts.append(text)
        font = pygame.font.SysFont('KaiTi', 14)
        hei = margin + 310
        for t in texts:
            print_text(screen, font, temp_size * qz_size + 2 * margin + 60, hei,
                       t, (0, 0, 0))
            hei += 25
        pygame.display.update()
        clock.tick(FPS)
    elaps_time = int(time.time() - stime)
    if elaps_time == otime:
        game_over_lose(screen, q, clock)
    if not times == -413:
        game_over_win(screen, q, clock, temp_size)
    gsta = 0
    stime = None
    elaps_time = 0
    rand_nob1 = random.randint(0, 8)
    rand_nob = rand_nob1
    rand_photo = img_dict[rand_nob]
    img = Image.open('photo/{}.jpg'.format(rand_photo))
    img = img.resize((photo_width, photo_height))
    img.save("photo/{}.jpg".format(rand_photo))
    img = Image.open('photo/{}.jpg'.format(rand_photo))
    imgwidth = img.width
    imgheight = img.height
    imgwe = imgwidth / temp_size
    imghe = imgheight / temp_size
    img_list = []
    cnt = 1
    for i in range(temp_size):
        for j in range(temp_size):
            leftupy = i * imghe
            leftupx = j * imgwe
            rightdowny = (i + 1) * imghe
            rightdownx = (j + 1) * imgwe
            tmps = (leftupx, leftupy, rightdownx, rightdowny)
            tmpimg = img.crop(tmps)
            tmpimg = tmpimg.resize((qz_size, qz_size))
            img_list.append(tmpimg)
            tmpimg.save('photo/imagee{}.jpg'.format(cnt))
            cnt += 1


if __name__ == "__main__":
    while True:
        main()
